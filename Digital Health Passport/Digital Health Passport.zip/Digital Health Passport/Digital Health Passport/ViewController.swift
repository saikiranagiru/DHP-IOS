//
//  ViewController.swift
//  Digital Health Passport
//
//  Created by student on 3/25/22.
//

import UIKit
import ArgumentParser


class ViewController: UIViewController {

    @IBOutlet weak var DHPID: UITextField!
    
    @IBOutlet weak var DHPPassword: UITextField!
    
    @IBOutlet weak var LoginButton: UIButton!
    
    @IBOutlet weak var Signup: UILabel!
    
        @IBOutlet weak var btnLogout: UIButton!
    
    override func viewDidLoad() {
            super.viewDidLoad()
    }
}
